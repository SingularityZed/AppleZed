package com.zed.admin.system.pojo.ao;

import lombok.Data;

import java.io.Serializable;

/**
 * QueryAO
 *
 * @Author: wang_ycong(Tel : 16602526966)
 * @Date: 2019/12/12 19:12
 */
@Data
public class DeleteAO implements Serializable {


}
